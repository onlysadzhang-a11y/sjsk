require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const helmet = require("helmet");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");
const { Server } = require("socket.io");

if (!process.env.DATABASE_URL || !process.env.SESSION_SECRET) {
  console.error("DATABASE_URL and SESSION_SECRET are required.");
  process.exit(1);
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  max: 10
});
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const sessionMiddleware = session({
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", maxAge: 30 * 24 * 60 * 60 * 1000 }
});
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "32kb" }));
app.use(sessionMiddleware);
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));
io.engine.use(sessionMiddleware);

io.on("connection", (socket) => {
  const uid = socket.request.session?.userId;
  if (uid) socket.join(`user:${uid}`);
});

const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const requireAuth = (req,res,next) => req.session.userId ? next() : res.status(401).json({ error: "请先登录" });
const requireAdmin = asyncRoute(async (req,res,next) => {
  if (!req.session.userId) return res.status(401).json({ error: "请先登录" });
  const { rows } = await pool.query("SELECT role FROM users WHERE id=$1", [req.session.userId]);
  if (rows[0]?.role !== "admin") return res.status(403).json({ error: "仅管理员可访问" });
  next();
});
const safeUser = u => ({ id: u.id, username: u.username, role: u.role, balance: Number(u.balance) });

app.get("/health", (req,res) => res.json({ ok: true }));
app.get("/api/me", asyncRoute(async (req,res) => {
  if (!req.session.userId) return res.json({ user: null });
  const { rows } = await pool.query("SELECT id,username,role,balance FROM users WHERE id=$1", [req.session.userId]);
  if (!rows[0]) { req.session.destroy(() => {}); return res.json({ user: null }); }
  res.json({ user: safeUser(rows[0]) });
}));
app.post("/api/register", asyncRoute(async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{4,32}$/.test(username)) return res.status(400).json({ error: "用户名需为 4–32 位字母、数字或下划线" });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "密码长度需为 10–128 位" });
  const hash = await bcrypt.hash(password, 12);
  try {
    const { rows } = await pool.query("INSERT INTO users(username,password_hash) VALUES($1,$2) RETURNING id,username,role,balance", [username,hash]);
    req.session.userId = rows[0].id;
    res.status(201).json({ user: safeUser(rows[0]) });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "用户名已存在" });
    throw e;
  }
}));
app.post("/api/login", asyncRoute(async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const { rows } = await pool.query("SELECT id,username,password_hash,role,balance FROM users WHERE username=$1", [username]);
  if (!rows[0] || !(await bcrypt.compare(password, rows[0].password_hash))) return res.status(401).json({ error: "用户名或密码不正确" });
  req.session.userId = rows[0].id;
  res.json({ user: safeUser(rows[0]) });
}));
app.post("/api/logout", (req,res) => req.session.destroy(() => { res.clearCookie("connect.sid"); res.json({ ok: true }); }));

app.get("/api/state", requireAuth, asyncRoute(async (req,res) => {
  const [u,c,r,e] = await Promise.all([
    pool.query("SELECT id,username,role,balance FROM users WHERE id=$1",[req.session.userId]),
    pool.query("SELECT return_target,volatility,updated_at FROM demo_config WHERE id=1"),
    pool.query("SELECT id,game_code,bet,payout,outcome,created_at FROM game_records WHERE user_id=$1 ORDER BY id DESC LIMIT 30",[req.session.userId]),
    pool.query("SELECT id,amount,created_at FROM envelopes WHERE user_id=$1 AND status='pending' ORDER BY id DESC",[req.session.userId])
  ]);
  res.json({ user: safeUser(u.rows[0]), config: c.rows[0], records: r.rows, envelopes: e.rows });
}));

app.post("/api/game/spin", requireAuth, asyncRoute(async (req,res) => {
  const game = ["777","journey"].includes(req.body.game) ? req.body.game : "777";
  const bet = Math.max(0.1, Math.min(1000, Number(req.body.bet) || 1));
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows: cfgRows } = await client.query("SELECT return_target,volatility FROM demo_config WHERE id=1");
    const target = Number(cfgRows[0]?.return_target ?? 76);
    const volatility = cfgRows[0]?.volatility || "high";
    const winChance = volatility === "low" ? 0.42 : volatility === "random" ? Math.random() * 0.5 + 0.08 : 0.16;
    const won = Math.random() < winChance && target > 0;
    const multiplier = won ? (Math.random() < 0.15 ? 8 : 1.2) * Math.max(0, target / 76) : 0;
    const payout = Math.round(bet * multiplier * 100) / 100;
    const symbols = game === "777"
      ? (won ? ["7","7","7"] : ["BAR","7","BAR"])
      : (won ? ["悟空","唐僧","八戒"] : ["云","金箍棒","云"]);
    const outcome = { symbols, won, multiplier: payout ? payout / bet : 0, demo: true };
    const { rows: bal } = await client.query("UPDATE users SET balance=balance-$1+$2 WHERE id=$3 AND balance >= $1 RETURNING balance", [bet,payout,req.session.userId]);
    if (!bal[0]) { await client.query("ROLLBACK"); return res.status(400).json({ error: "虚拟余额不足" }); }
    const { rows: rec } = await client.query("INSERT INTO game_records(user_id,game_code,bet,payout,outcome) VALUES($1,$2,$3,$4,$5) RETURNING id,created_at", [req.session.userId,game,bet,payout,outcome]);
    await client.query("COMMIT");
    res.json({ balance: Number(bal[0].balance), record: { ...rec[0], bet, payout, outcome } });
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}));

app.get("/api/envelopes/pending", requireAuth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query("SELECT id,amount,created_at FROM envelopes WHERE user_id=$1 AND status='pending' ORDER BY id DESC", [req.session.userId]);
  res.json({ envelopes: rows });
}));
app.post("/api/envelopes/:id/claim", requireAuth, asyncRoute(async (req,res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows } = await client.query("UPDATE envelopes SET status='claimed',claimed_at=NOW() WHERE id=$1 AND user_id=$2 AND status='pending' RETURNING amount", [req.params.id,req.session.userId]);
    if (!rows[0]) { await client.query("ROLLBACK"); return res.status(409).json({ error: "红包不存在或已经领取" }); }
    const { rows: u } = await client.query("UPDATE users SET balance=balance+$1 WHERE id=$2 RETURNING balance", [rows[0].amount,req.session.userId]);
    await client.query("COMMIT");
    res.json({ amount: Number(rows[0].amount), balance: Number(u[0].balance) });
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); }
}));

app.get("/api/admin/users", requireAdmin, asyncRoute(async (req,res) => {
  const q = `%${String(req.query.q || "").slice(0,32)}%`;
  const { rows } = await pool.query("SELECT id,username,role,balance,created_at FROM users WHERE username ILIKE $1 ORDER BY id DESC LIMIT 50",[q]);
  res.json({ users: rows });
}));
app.post("/api/admin/config", requireAdmin, asyncRoute(async (req,res) => {
  const target = Number(req.body.returnTarget);
  const volatility = String(req.body.volatility);
  if (!Number.isFinite(target) || target < 0 || target > 200 || !["high","low","random"].includes(volatility)) return res.status(400).json({ error: "参数无效（测试返还参数 0–200）" });
  const { rows } = await pool.query("UPDATE demo_config SET return_target=$1,volatility=$2,updated_at=NOW(),updated_by=$3 WHERE id=1 RETURNING *",[target,volatility,req.session.userId]);
  io.emit("demo-config-updated", { returnTarget: target, volatility });
  res.json({ config: rows[0] });
}));
app.post("/api/admin/envelopes", requireAdmin, asyncRoute(async (req,res) => {
  const username = String(req.body.username || "").trim();
  const min = Number(req.body.min);
  const max = Number(req.body.max);
  if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || min < 1 || max < min || max > 18888888) return res.status(400).json({ error: "金额范围需为 1 至 18,888,888 的整数，且下限不大于上限" });
  const { rows: users } = await pool.query("SELECT id FROM users WHERE username=$1",[username]);
  if (!users[0]) return res.status(404).json({ error: "未找到该账户" });
  const amount = Math.floor(Math.random() * (max-min+1)) + min;
  const { rows } = await pool.query("INSERT INTO envelopes(user_id,amount) VALUES($1,$2) RETURNING id,amount,created_at",[users[0].id,amount]);
  io.to(`user:${users[0].id}`).emit("envelope:new", { id: rows[0].id, amount: Number(rows[0].amount) });
  res.status(201).json({ envelope: rows[0] });
}));

app.use((err,req,res,next) => {
  console.error(err);
  res.status(500).json({ error: "服务器暂时无法处理请求" });
});
const port = Number(process.env.PORT || 10000);
server.listen(port, "0.0.0.0", () => console.log(`Listening on ${port}`));