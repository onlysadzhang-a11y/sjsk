require("dotenv").config();
const bcrypt = require("bcryptjs");
const { Pool } = require("pg");
const [username, password] = process.argv.slice(2);
if (!username || !password || password.length < 12) {
  console.error('Usage: npm run admin:create -- <username> <password-at-least-12-chars>');
  process.exit(1);
}
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false });
(async () => {
  try {
    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      `INSERT INTO users (username,password_hash,role) VALUES ($1,$2,'admin')
       ON CONFLICT (username) DO UPDATE SET password_hash=EXCLUDED.password_hash, role='admin'`,
      [username, hash]
    );
    console.log(`Admin account "${username}" created/updated.`);
  } catch (e) { console.error(e); process.exitCode = 1; }
  finally { await pool.end(); }
})();