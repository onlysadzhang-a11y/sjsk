require("dotenv").config();
const { Pool } = require("pg");
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false });
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id BIGSERIAL PRIMARY KEY,
        username VARCHAR(32) UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role VARCHAR(16) NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
        balance NUMERIC(20,2) NOT NULL DEFAULT 0,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE TABLE IF NOT EXISTS demo_config (
        id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
        return_target NUMERIC(6,2) NOT NULL DEFAULT 76,
        volatility VARCHAR(16) NOT NULL DEFAULT 'high',
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_by BIGINT REFERENCES users(id)
      );
      CREATE TABLE IF NOT EXISTS envelopes (
        id BIGSERIAL PRIMARY KEY,
        user_id BIGINT NOT NULL REFERENCES users(id),
        amount NUMERIC(20,2) NOT NULL,
        status VARCHAR(16) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','claimed')),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        claimed_at TIMESTAMPTZ
      );
      CREATE TABLE IF NOT EXISTS game_records (
        id BIGSERIAL PRIMARY KEY,
        user_id BIGINT NOT NULL REFERENCES users(id),
        game_code VARCHAR(32) NOT NULL,
        bet NUMERIC(20,2) NOT NULL,
        payout NUMERIC(20,2) NOT NULL,
        outcome JSONB NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      INSERT INTO demo_config (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
    `);
    console.log("Database schema ready.");
  } catch (e) { console.error(e); process.exitCode = 1; }
  finally { await pool.end(); }
})();