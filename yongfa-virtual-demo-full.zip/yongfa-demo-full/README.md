# 永發娛樂 · 虚拟演示系统

这是一个可部署到 Render 的 Node.js + Express + PostgreSQL 项目。它提供：
- 用户注册、登录、持久化账户与虚拟余额
- 管理员角色与服务端权限校验
- 全局虚拟游戏测试参数（仅演示）
- 管理员向指定用户派发随机虚拟红包，Socket.IO 实时通知，单次领取
- 超级 777 / 西游记两个虚拟游戏入口与游戏记录
- PostgreSQL 持久化，关闭浏览器或更换设备后仍可重新登录

**重要：** 本项目是透明标注的虚拟演示系统。V-PTS 不具有现金或 USDT 价值；不接入真实博彩资金、充值、提现、钱包地址或链上交易。演示参数不是任何真实博彩产品的 RTP。

## 本地运行
1. 安装 Node.js 20+
2. 创建 PostgreSQL 数据库
3. `cp .env.example .env` 并填写 `DATABASE_URL` 与随机 `SESSION_SECRET`
4. `npm install`
5. `npm run db:init`
6. `npm run admin:create -- admin YOUR_LONG_UNIQUE_PASSWORD`
7. `npm start`
8. 打开 `http://localhost:10000`

注册用户可直接在页面创建。管理员账号通过命令行创建，不在前端写死密码。

## Render 部署
仓库内包含 `render.yaml` Blueprint。把项目文件上传到 GitHub 仓库后，在 Render Dashboard 选择 New > Blueprint，连接仓库并应用 Blueprint。数据库与 Web Service 会一并创建。首次部署后，需要在 Render Shell 执行：
`npm run admin:create -- admin YOUR_LONG_UNIQUE_PASSWORD`
请使用唯一强密码，不要把密码提交到 GitHub。

## 数据和安全说明
- 密码使用 bcrypt 哈希保存。
- Session 存储在 PostgreSQL，cookie 为 HttpOnly、SameSite=Lax，生产环境启用 Secure。
- 管理员接口在服务端检查角色，不能通过修改前端绕过。
- 游戏、余额和红包使用数据库事务，红包只能领取一次。
- 建议启用数据库备份，并定期验证恢复流程。
